import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
SERVER_HOST = os.getenv("SERVER_HOST", "0.0.0.0")
SERVER_PORT = int(os.getenv("SERVER_PORT", "8000"))
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",")]
