import asyncio, json
from fastapi import APIRouter, HTTPException, Depends
from sse_starlette.sse import EventSourceResponse
from app.schemas import RephraseRequest, RephraseResponse, CancelResponse
from app.services.rephrase_service import RephraseService
from app.providers.openai_chat import OpenAIChatProvider
from app.providers.mock_provider import MockProvider
from app.utils.cancel import cancel_registry

router = APIRouter(prefix="/v1/rephrase", tags=["rephrase"])

def get_service() -> RephraseService:
    provider = OpenAIChatProvider()
    return RephraseService(provider)

@router.post("", response_model=RephraseResponse)
async def rephrase(req: RephraseRequest, svc: RephraseService = Depends(get_service)):
    styles = svc.validate_styles(req.styles)
    rid = req.ensure_request_id()
    try:
        results = await svc.rephrase_all_full(styles, req.input_text)
        return RephraseResponse(request_id=rid, results=results)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@router.post("/stream")
async def rephrase_stream(req: RephraseRequest, svc: RephraseService = Depends(get_service)):
    styles = svc.validate_styles(req.styles)
    rid = req.ensure_request_id()
    cancel_ev = cancel_registry.create(rid)

    async def gen():
        try:
            yield {"event": "meta", "data": json.dumps({"request_id": rid})}
            for style in styles:
                if cancel_ev.is_set():
                    break
                yield {"event": "style_start", "data": style}
                async for delta in svc.stream_style(style, req.input_text):
                    if cancel_ev.is_set():
                        break
                    yield {"event": "delta", "data": json.dumps({"style": style, "delta": delta})}
                yield {"event": "style_end", "data": style}
            yield {"event": "done", "data": "[DONE]"}
        finally:
            cancel_registry.clear(rid)

    return EventSourceResponse(gen())

@router.post("/{request_id}/cancel", response_model=CancelResponse)
async def cancel(request_id: str):
    ok = cancel_registry.cancel(request_id)
    return CancelResponse(request_id=request_id, cancelled=ok)
