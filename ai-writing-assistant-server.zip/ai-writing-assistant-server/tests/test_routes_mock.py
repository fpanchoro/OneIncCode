import pytest
from httpx import AsyncClient
from fastapi import FastAPI
from app.main import app as real_app
from app.services.rephrase_service import RephraseService
from app.providers.mock_provider import MockProvider

@pytest.fixture
def app():
    app = real_app
    from app.routes import rephrase as mod
    def get_service_override():
        return RephraseService(MockProvider())
    mod.get_service = get_service_override
    return app

@pytest.mark.asyncio
async def test_rephrase_full(app: FastAPI):
    async with AsyncClient(app=app, base_url="http://test") as ac:
        payload = {"input_text": "Hello team", "styles": ["professional", "casual"]}
        r = await ac.post("/v1/rephrase", json=payload)
        assert r.status_code == 200
        data = r.json()
        assert "results" in data

@pytest.mark.asyncio
async def test_stream_sse(app: FastAPI):
    async with AsyncClient(app=app, base_url="http://test") as ac:
        r = await ac.post("/v1/rephrase/stream", json={"input_text":"Hi","styles":["polite"]})
        assert r.status_code == 200
        assert r.headers.get("content-type", "").startswith("text/event-stream")
