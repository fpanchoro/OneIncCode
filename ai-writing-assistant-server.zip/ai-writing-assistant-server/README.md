# AI Writing Assistant Server (FastAPI)

Backend que reescribe texto en estilos: Professional, Casual, Polite y Social-media.
Incluye endpoints de streaming (SSE) y cancelación.

## Requisitos
- Python 3.11
- (opcional) Docker

## Setup
1) `cp .env.example .env` y pon tu `OPENAI_API_KEY`.
2) `pip install -r requirements.txt`
3) `uvicorn app.main:app --reload`

## Endpoints
- `POST /v1/rephrase`
- `POST /v1/rephrase/stream`
- `POST /v1/rephrase/{request_id}/cancel`

## Tests
- `pytest -q`

## Docker
- `docker build -t ai-writing-server .`
- `docker run -p 8000:8000 --env-file .env ai-writing-server`
